#ifndef BUZZERMELDY_H
#define BUZZERMELDY_H

#include <Arduino.h>

class BuzzerMelody {
public:
    BuzzerMelody(int pin);
    void playMelody();
    
private:
    int buzzer;
    int melody[20] = {
        293,  // D
        293,  // D
        293,  // D
        349,  // F
        440,  // A
        293,  // D
        349,  // F
        440,  // A
        293,  // D
        349,  // F
        440,  // A
        293,  // D
        261,  // C
        293,  // D
        349,  // F
        440,  // A
        293,  // D
        293,  // D
        349,  // F
        440,  // A
        261   // C
    };
    int noteDurations[20] = {
        4, 4, 4, 4, 4, 4, 4, 4,
        4, 4, 4, 4, 4, 4, 4, 4,
        4, 4, 4, 4, 4
    };
};

#endif
