#include "BuzzerMelody.h"

BuzzerMelody::BuzzerMelody(int pin) {
    buzzer = pin;
    pinMode(buzzer, OUTPUT);
}

void BuzzerMelody::playMelody() {
    for (int thisNote = 0; thisNote < 20; thisNote++) {
        // Calcular a duração da nota
        int noteDuration = 1000 / noteDurations[thisNote];

        // Tocar a nota correspondente na frequência determinada
        tone(buzzer, melody[thisNote], noteDuration);

        // Esperar pela duração da nota mais um pequeno intervalo
        int pauseBetweenNotes = noteDuration * 1.30;
        delay(pauseBetweenNotes);

        // Parar o som entre as notas
        noTone(buzzer);
    }
}
